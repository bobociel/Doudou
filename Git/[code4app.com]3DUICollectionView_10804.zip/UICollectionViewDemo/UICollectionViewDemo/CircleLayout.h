//
//  CircleLayout.h
//  UICollectionViewDemo
//
//  Created by Lee on 14-2-14.
//  Copyright (c) 2014年 Lee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CircleLayout : UICollectionViewLayout

@end
