//
//  ViewController.m
//  CoreImage效果测试
//
//  Created by zmit on 15/3/31.
//  Copyright (c) 2015年 zmit. All rights reserved.
//

#import "ViewController.h"

#define ScreenWidth [self.view bounds].size.width
#define ScreenHeight [self.view bounds].size.height

@interface ViewController () <UIPickerViewDataSource, UIPickerViewDelegate>
{
    NSMutableArray *_pickerData;//关系选择器数组
    UIPickerView *pickerView;//关系选择器
    UIImageView *imageView;//imageView
    UIImage *originImage;//源图片
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //单击手势
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(showPicker)];
    tapGesture.numberOfTapsRequired = 1;//手势敲击的次数
    [self.view addGestureRecognizer:tapGesture];
    
    //源图片
    originImage = [[UIImage alloc] init];
    originImage = [UIImage imageNamed:@"091504276044781"];
    
    //imageView
    imageView = [[UIImageView alloc] initWithImage:originImage];
    imageView.frame = self.view.frame;
    imageView.center = self.view.center;
    [self.view addSubview:imageView];
    
    _pickerData = [[NSMutableArray alloc] initWithObjects:
                   @"OriginImage",
                   @"CIPhotoEffectMono",
                   @"CIPhotoEffectChrome",
                   @"CIPhotoEffectFade",
                   @"CIPhotoEffectInstant",
                   @"CIPhotoEffectNoir",
                   @"CIPhotoEffectProcess",
                   @"CIPhotoEffectTonal",
                   @"CIPhotoEffectTransfer",
                   @"CISRGBToneCurveToLinear",
                   @"CIVignetteEffect",
                   nil];
    [self addPickerView];
}

#pragma mark 滤镜处理事件
- (void)fliterEvent:(NSString *)filterName
{
    if ([filterName isEqualToString:@"OriginImage"]) {
        imageView.image = originImage;
    
    }else{
        //将UIImage转换成CIImage
        CIImage *ciImage = [[CIImage alloc] initWithImage:originImage];
        
        //创建滤镜
        CIFilter *filter = [CIFilter filterWithName:filterName keysAndValues:kCIInputImageKey, ciImage, nil];
        
        //已有的值不改变，其他的设为默认值
        [filter setDefaults];
        
        //获取绘制上下文
        CIContext *context = [CIContext contextWithOptions:nil];
        
        //渲染并输出CIImage
        CIImage *outputImage = [filter outputImage];
        
        //创建CGImage句柄
        CGImageRef cgImage = [context createCGImage:outputImage fromRect:[outputImage extent]];
        
        //获取图片
        UIImage *image = [UIImage imageWithCGImage:cgImage];
        
        //释放CGImage句柄
        CGImageRelease(cgImage);
        
        imageView.image = image;
    }
    
}

#pragma mark 开关选择器
- (void)showPicker
{
    static int i = 0;
    i++;
    
    if (i % 2 == 1) {
        //picker显示
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.3];//动画时间0.3s
        pickerView.frame = CGRectMake(0, ScreenHeight - CGRectGetHeight(pickerView.bounds), ScreenWidth, CGRectGetHeight(pickerView.bounds));
        [UIView commitAnimations];
    }else{
        //picker关闭
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.3];//动画时间0.3s
        pickerView.frame = CGRectMake(0, ScreenHeight, ScreenWidth, CGRectGetHeight(pickerView.bounds));
        [UIView commitAnimations];
    }
}

#pragma mark - 选择器

- (void) addPickerView{
    //pickerView
    int pickerHeight = 200;//pickerView的高度
    pickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(0, ScreenHeight, ScreenWidth, pickerHeight)];
    pickerView.delegate = self;
    pickerView.dataSource = self;
    pickerView.showsSelectionIndicator = YES;
    pickerView.backgroundColor = [UIColor colorWithWhite:0.8 alpha:0.9];
    [self.view addSubview:pickerView];
    
}

//返回pickerview的组件数
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)thePickerView {
    return 1;
}

//返回每个组件上的行数
- (NSInteger)pickerView:(UIPickerView *)thePickerView numberOfRowsInComponent:(NSInteger)component {
    return [_pickerData count];
}

//设置每行显示的内容
- (NSString *)pickerView:(UIPickerView *)thePickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    return [_pickerData objectAtIndex:row];
}

//当你选中pickerview的某行时会调用该函数。
- (void)pickerView:(UIPickerView *)thePickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    
    [self fliterEvent:[_pickerData objectAtIndex:row]];
}

@end
