# Perfect - MySQL Connector

## Linux Build Notes
* Ensure that you have installed *libmysqlclient-dev*.
* make
