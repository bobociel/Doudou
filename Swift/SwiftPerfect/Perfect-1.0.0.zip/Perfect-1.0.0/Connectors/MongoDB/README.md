# Perfect - MongoDB Connector

## Linux Build Notes

* Follow these instructions for installing libmongoc: [libmongoc](http://api.mongodb.org/c/current/installing.html)
* make