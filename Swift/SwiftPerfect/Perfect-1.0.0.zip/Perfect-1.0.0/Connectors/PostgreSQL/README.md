# Perfect - PostgreSQL Connector

## Linux Build Notes
* Ensure that you have installed *libpq-dev*.
* make
