//
//  AppDelegate.h
//  ExampleTTOpenInAppActivity
//
//  Created by Tobias Tiemerding on 1/10/13.
//  Copyright (c) 2013 Tobias Tiemerding. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
