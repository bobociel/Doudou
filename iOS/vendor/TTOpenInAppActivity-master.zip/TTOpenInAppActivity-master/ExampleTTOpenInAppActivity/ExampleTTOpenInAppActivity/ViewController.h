//
//  ViewController.h
//  ExampleTTOpenInAppActivity
//
//  Created by Tobias Tiemerding on 1/10/13.
//  Copyright (c) 2013 Tobias Tiemerding. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
