//
//  DanmakuTime.h
//  DanmakuDemo
//
//  Created by haijiao on 15/3/1.
//  Copyright (c) 2015年 olinone. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DanmakuTime : NSObject

@property (nonatomic, assign) float time;
@property (nonatomic, assign) float interval;

@end
