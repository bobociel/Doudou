# HJDanmakuDemo

###iOS系统上弹幕源码实现###
![](http://7pum7o.com1.z0.glb.clouddn.com/danmaku.jpg)

---

####更多细节请访问网站####
http://www.olinone.com/?p=186

适配环境 iOS5+  ARC

---

####The MIT License####
Copyright (c) 2015 olinone
