//
//  AppDelegate.h
//  testFliterView
//
//  Created by hangzhou on 15/2/4.
//  Copyright (c) 2015年 hangzhou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

