# 360-Degree-Pan# 360-Degree-Pane-Panama
===================

### 这是一个什么项目：   
项目以PhoneGAP 为基础，结合Html5 的技术来做成一个3D浏览的效果。

### 使用到的技术：
[PhoneGAP](http://phonegap.com/)(需要梯子),HTML5,[pano2vr](http://www.pano2vr.com)

### 如何编译
[编译](http://docs.phonegap.com/en/2.0.0/guide_cordova-webview_ios.md.html#Embedding%20Cordova%20WebView%20on%20iOS)



### What is the Project
This Projcet Used html5 and phonegap to do . also you can see PanoramaGL . 

### Tool
[PhoneGAP](http://www.phonegap.com),HTML5,[pano2vr](http://www.pano2vr.com)

### How to build
[Build](http://docs.phonegap.com/en/2.0.0/guide_cordova-webview_ios.md.html#Embedding%20Cordova%20WebView%20on%20iOS)

Enjoy it ! 

