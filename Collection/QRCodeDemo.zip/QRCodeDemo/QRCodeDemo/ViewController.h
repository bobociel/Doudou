//
//  ViewController.h
//  JB_ZBarSDK_Demo
//
//  Created by jaybin on 15/8/26.
//  Copyright (c) 2015年 jaybin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZBarSDK.h"

@interface ViewController : UIViewController<ZBarReaderDelegate>


@end

