//
//  MJViewController.m
//  ParallaxImages
//
//  Created by Mayur on 4/1/14.
//  Copyright (c) 2014 sky. All rights reserved.
//

#import "MJRootViewController.h"
#import "MJCollectionViewCell.h"
#define MAXSECTION 100
@interface MJRootViewController () <UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, UIScrollViewDelegate>

@property (weak, nonatomic) IBOutlet UICollectionView *parallaxCollectionView;
@property (nonatomic, strong) NSMutableArray* images;
@property (nonatomic, strong) NSTimer* timer;
@end

@implementation MJRootViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    // Fill image array with images
    NSUInteger index;
    for (index = 0; index < 14; ++index) {
        // Setup image name
        NSString *name = [NSString stringWithFormat:@"image%03ld.jpg", (unsigned long)index];
        if(!self.images)
            self.images = [NSMutableArray arrayWithCapacity:0];
        [self.images addObject:name];
    }

    [self.parallaxCollectionView reloadData];
//	[self.parallaxCollectionView scrollToItemAtIndexPath:[NSIndexPath indexPathForItem:0 inSection:MAXSECTION/2] atScrollPosition:UICollectionViewScrollPositionLeft animated:NO];

	[self addTimer];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UICollectionViewDatasource Methods
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
	return MAXSECTION;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.images.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    MJCollectionViewCell* cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"MJCell" forIndexPath:indexPath];
    
    //get image name and assign
    NSString* imageName = [self.images objectAtIndex:indexPath.item];
    cell.image = [UIImage imageNamed:imageName];
    
    //set offset accordingly
    CGFloat xOffset = ((self.parallaxCollectionView.contentOffset.x - cell.frame.origin.x) / IMAGE_WIDTH) * IMAGE_OFFSET_SPEED;
    cell.imageOffset = CGPointMake(xOffset, 0.0f);

    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
	return CGSizeMake([UIScreen mainScreen].bounds.size.width, 300);
}
#pragma mark -  Timer
- (void)addTimer
{
	_timer = [NSTimer scheduledTimerWithTimeInterval:3 target:self selector:@selector(nextPage) userInfo:nil repeats:YES];
	[[NSRunLoop mainRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
}

- (void)removeTimer
{
	[_timer invalidate];
	_timer = nil;
}

#pragma mark - UIScrollViewdelegate methods
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    for(MJCollectionViewCell *view in self.parallaxCollectionView.visibleCells) {
		CGFloat xOffset = ((self.parallaxCollectionView.contentOffset.x - view.frame.origin.x) / IMAGE_WIDTH) * IMAGE_OFFSET_SPEED;
		if(xOffset < 0){
			view.imageOffset = CGPointMake(xOffset, 0.0f);
		}
    }
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
	[self removeTimer];
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
	[self addTimer];
}

- (void)nextPage
{
	NSIndexPath *currentIndexPath = [[self.parallaxCollectionView indexPathsForVisibleItems] lastObject];

//	NSIndexPath *currentIndexPathReset = [NSIndexPath indexPathForItem:currentIndexPath.item inSection:MAXSECTION/2];
//	[self.parallaxCollectionView scrollToItemAtIndexPath:currentIndexPathReset atScrollPosition:UICollectionViewScrollPositionLeft animated:NO];

	NSInteger nextItem = currentIndexPath.item + 1;
	NSInteger nextSection = currentIndexPath.section;
	if (nextItem == self.images.count) {
		nextItem = 0;
		nextSection += 1;
	}

	NSIndexPath *nextIndexPath = [NSIndexPath indexPathForItem:nextItem inSection:nextSection];

	[self.parallaxCollectionView scrollToItemAtIndexPath:nextIndexPath atScrollPosition:UICollectionViewScrollPositionLeft animated:YES];

//	IMAGE_WIDTH*0.002/2
//	self.parallaxCollectionView.contentOffset = CGPointMake(self.parallaxCollectionView.contentOffset.x + 0.3, 0);
}

@end
