//
//  Demo4ViewController.h
//  YXCollectionView
//
//  Created by yixiang on 15/10/15.
//  Copyright © 2015年 yixiang. All rights reserved.
//

#import "BaseViewController.h"

@interface Demo4ViewController : BaseViewController

@end
