//
//  Demo6Cell.h
//  YXCollectionView
//
//  Created by yixiang on 15/10/21.
//  Copyright © 2015年 yixiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Demo6Cell : UICollectionViewCell

@property (nonatomic , strong) NSString *imageName;

@end
