//
//  Demo5HeaderView.h
//  YXCollectionView
//
//  Created by yixiang on 15/10/19.
//  Copyright © 2015年 yixiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Demo5HeaderView : UICollectionReusableView

@property (nonatomic , strong) NSString *iconName;

@end
