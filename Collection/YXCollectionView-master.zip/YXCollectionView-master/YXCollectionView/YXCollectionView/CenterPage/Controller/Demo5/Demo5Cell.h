//
//  Demo5Cell.h
//  YXCollectionView
//
//  Created by yixiang on 15/10/19.
//  Copyright © 2015年 yixiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Demo5Cell : UICollectionViewCell

@property (nonatomic , strong) NSString *title;

@end
