//
//  YYCell.h
//  图片轮播（无限循环）
//
//  Created by yixiang on 14/12/12.
//  Copyright (c) 2014年 yixiang. All rights reserved.
//

#import <UIKit/UIKit.h>
@class YYNews;


@interface YYCell : UICollectionViewCell
@property (nonatomic, strong) YYNews *news;
@end
