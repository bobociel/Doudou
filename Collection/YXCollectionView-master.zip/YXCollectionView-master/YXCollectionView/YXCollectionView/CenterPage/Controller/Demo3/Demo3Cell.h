//
//  Demo3Cell.h
//  YXCollectionView
//
//  Created by yixiang on 15/10/12.
//  Copyright © 2015年 yixiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Demo3Cell : UICollectionViewCell

@property (nonatomic , strong) NSString *imageName;

@end
