//
//  Demo3ViewController.h
//  YXCollectionView
//
//  Created by yixiang on 15/10/11.
//  Copyright © 2015年 yixiang. All rights reserved.
//

#import "BaseViewController.h"

@interface Demo3ViewController : BaseViewController

@end
