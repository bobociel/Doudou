//
//  Demo1Cell.h
//  YXCollectionView
//
//  Created by yixiang on 15/10/11.
//  Copyright © 2015年 yixiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Demo1Cell : UICollectionViewCell

- (void)setImageName : (NSString *)imageName content : (NSString *)content;

@end
