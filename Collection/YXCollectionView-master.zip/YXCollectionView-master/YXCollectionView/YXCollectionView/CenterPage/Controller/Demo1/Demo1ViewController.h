//
//  Demo1ViewController.h
//  YXUICollectionViewDemo
//
//  Created by yixiang on 15/10/10.
//  Copyright © 2015年 yixiang. All rights reserved.
//

#import "BaseViewController.h"

@interface Demo1ViewController : BaseViewController

@end
