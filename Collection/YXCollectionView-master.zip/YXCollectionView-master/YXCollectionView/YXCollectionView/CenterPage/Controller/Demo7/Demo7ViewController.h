//
//  Demo7ViewController.h
//  YXCollectionView
//
//  Created by yixiang on 15/11/6.
//  Copyright © 2015年 yixiang. All rights reserved.
//

#import "BaseViewController.h"

@interface Demo7ViewController : BaseViewController

@end
